package primality;

public class PrimalityTest {

    public static boolean isPrime(int number) {
        return false;
    }
}
