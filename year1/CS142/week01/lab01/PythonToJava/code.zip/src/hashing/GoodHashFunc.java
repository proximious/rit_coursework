package hashing;

public class GoodHashFunc {

    public static int computeHash(String input) {
        return 0;
    }

}
