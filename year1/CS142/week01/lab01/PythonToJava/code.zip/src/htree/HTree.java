package htree;

import static turtle.Turtle.*;

public class HTree {

    public static void main(String[] args) {
    }

}
