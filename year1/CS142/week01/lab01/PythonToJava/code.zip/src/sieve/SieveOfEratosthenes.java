package sieve;

public class SieveOfEratosthenes {

    public static int[] makeSieve(int upperBound) {
        return new int[0];
    }

}
