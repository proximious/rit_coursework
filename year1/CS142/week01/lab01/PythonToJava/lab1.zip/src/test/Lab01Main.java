package test;

import hashing.GoodHashFunc;
import primality.PrimalityTest;
import sieve.SieveOfEratosthenes;

/**
 * This class encapsulates a test program provided to students so that they
 * can test their implementations of the various parts of the lab. This class
 * will not test the standalone execution of each class (e.g. the main
 * method), but will instead call the required helper functions directly in
 * each of the implementation classes.
 *
 * @author RIT CS
 */
public class Lab01Main {
    /**
     * A truth table for the prime numbers between 0 and 1000.
     */
    public static final int[] PRIME_TRUTH_TABLE = {
            1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
            1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,
            1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0,
            1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
            1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0,
            1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
            1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
            1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0,
            1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0,
            1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,
            1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1,
            1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0,
            1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1,
            1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
            1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1
    };

    /**
     * Tests the {@link GoodHashFunc#computeHash(String)} method to verify
     * that it is functioning properly with a few test strings.
     */

    public static void testGoodHashFunc() {
        System.out.println("Testing GoodHashFunc...");

        for(char a='a'; a<='z'; a++) {
            for(char b='a'; b<='z'; b++) {
                for(char c='a'; c<='z'; c++) {
                    char[] chars = {a, b, c};
                    String input = new String(chars);

                    int expected = input.hashCode();
                    int result = GoodHashFunc.computeHash(input);

                    if(expected != result) {
                        System.out.println("  hash function test failed '" +
                            input + "'; expected " + expected + " but got " +
                            result);
                        return;
                    }
                }
            }
        }
        System.out.println("  all hash function tests passed!");

    }

    /**
     * Tests the {@link PrimalityTest#isPrime(int)} function to verify that
     * it returns the correct result for all numbers in the range 0-1000.
     */
    public static void testPrimality() {
        System.out.println("Testing PrimalityTest...");
        for(int i=0; i<PRIME_TRUTH_TABLE.length; i++) {
            boolean expected = PRIME_TRUTH_TABLE[i] == 0;
            boolean result = PrimalityTest.isPrime(i);

            if(expected != result) {
                System.out.println("  Primality test failed: '" + i +
                        "'; expected " + expected + " but got " + result);
                // prevents ~1000 error messages...
                return;
            }
        }
        System.out.println("  all primality tests passed!");
    }

    /**
     * Tests the {@link SieveOfEratosthenes#makeSieve(int)} method by making
     * a sieve and comparing it to the {@link #PRIME_TRUTH_TABLE}.
     */
    public static void testSieve() {
        System.out.println("Testing SieveOfEratosthenes...");

        int[] sieve = SieveOfEratosthenes.makeSieve(PRIME_TRUTH_TABLE.length);

        for(int i=0; i<PRIME_TRUTH_TABLE.length; i++) {
            boolean expected = PRIME_TRUTH_TABLE[i] == 0;

            if (sieve.length == 0) {
                System.out.println("  Sieve of Eratosthenes test failed. '" +
                        i + "'; expected " + expected + " but got nothiing");
                return;
            } else {
                boolean result = sieve[i] == 0;

                if (expected != result) {
                    System.out.println("  Sieve of Eratosthenes test failed: '" +
                            i + "'; expected " + expected + " but got " + result);
                    // prevents ~1000 error messages...
                    return;
                }
            }
        }
        System.out.println("  all Sieve of Eratosthenes tests passed!");
    }

    /**
     * Tests each of the 4 activities from this lab.
     *
     * @param args Command line arguments; ignored.
     */
    public static void main(String[] args) {
        // activity 1
        testGoodHashFunc();

        // activity 2
        testPrimality();

        // activity 3
        testSieve();
    }
}
