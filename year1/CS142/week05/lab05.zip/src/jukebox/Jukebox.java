package jukebox;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * @author Alex Iacob ai9388@rit.edu
 *
 */
public class Jukebox {
    final static int SIMULATION_ITERATIONS = 50000;
    static int PLAY_COUNT = 0;
    private static String MOST_PLAYED_ARTIST;
    Random rand = new Random();
    private HashMap<Song, Integer> jukebox = new HashMap<>();
    /**
     * creating instance of a Jukebox that contains the title and artist
     * the function iterates until the end of the file by checking if the next line exists
     * each iteration puts a song title & artist with the times played into the hash map
     * each time the same song appears, timesPlayed is increased by 1
     * otherwise it is being placed as a new song
     */
    public Jukebox(String filename, int seed) throws FileNotFoundException {
        Scanner fileInput = new Scanner(new File(filename));
        this.rand = new Random(seed);

        while (fileInput.hasNextLine()) {
            String line = fileInput.nextLine();
            String[] lineArray = line.split("<SEP>");
            Song song;
            if (lineArray.length < 4){
                song = new Song(lineArray[2], "");
            }else{
                song = new Song(lineArray[2], lineArray[3]);
            }
            jukebox.put(song, 0);
        }
    }

    /**
     * runs a simulation of 50k iterations of jukebox each unique song
     * is being placed in a hash set(jukeSet)every copy of a song goes into
     * 'jukebox', which also stores the individual play count of each song
     */
    public void simulation(){

        ArrayList<Song> jukeList = new ArrayList<>(jukebox.keySet());

        for( int iteration = 0; iteration < SIMULATION_ITERATIONS; iteration ++) {
            HashSet<Song> jukeSet = new HashSet<>();

            while (true){
                int randomIndex = rand.nextInt(jukebox.size());
                Song song = jukeList.get(randomIndex);
                if (jukeSet.contains(song)) {
                    break;
                } else {
                    jukebox.put(song, jukebox.get(song) + 1);
                    jukeSet.add(song);
                    PLAY_COUNT++;
                }
            }
        }
    }


    /**
     * returns the total amount of songs being played throughout the iterations.
     * an iteration occurs each time a song repeats and is stored as a global variable
     * @return int: global variable PLAY_COUNT
     */
    public int totalSongs(){
        return PLAY_COUNT;
    }

    
    /**
     * contains the amount of time it takes to finish 50k iterations
     * calculates time in milliseconds, divides by 1000 to get seconds
     * @return long: total time in seconds
     */
    public long totalTime(){
        long start = System.currentTimeMillis();
        simulation();
        long end = System.currentTimeMillis();

        long delta = end - start;

        return delta / 1000;
    }

    
    /**
     * keeps track of each amount of songs it took to get a repeat
     * once total iterations are finished, numbers are averaged
     * @return int: average number of songs it took to reach the repeat of a song
     */
    public int averageNumberOfSongs(){
        return totalSongs() / SIMULATION_ITERATIONS;
    }

    
    /**
     * keeps track of the most commonly played song
     * @return String: title and artist of most played song
     */
    public String mostPlayedSong() {
        Map.Entry<Song, Integer> max = null;
        for (Map.Entry<Song, Integer> entry : jukebox.entrySet()) {
            if (max == null){
                max = entry;
            } else if(entry.getValue() > max.getValue()){
                 max = entry;
            }
        }
        MOST_PLAYED_ARTIST = max.getKey().getArtist();
        return "\"" + max.getKey().getSong() + "\" by \"" + max.getKey().getArtist() + "\"";
    }

    /**
     * sorts the songs from the top played artist
     * verifies if the song is by the same artist before printing out
     */
    public void alphabeticalSorting(){
        TreeMap<Song, Integer> sorted = new TreeMap<>(jukebox);

        for (Map.Entry<Song, Integer> entry : sorted.entrySet()) {
            if(entry.getKey().getArtist().equals(MOST_PLAYED_ARTIST)){
                System.out.println("\t \"" + entry.getKey().getSong() + "\" with " + entry.getValue() + " plays");
            }
        }
    }

    /**
     * does the pretty prints for the program
     * shows the size of the jukebox, the time of the simulation, the total
     * iterations, the total songs played, the average number of songs per iteration,
     * the most played song&artist, and the alphabetical sorting of the same
     * artist's remaining songs
     * @param music: the jukebox
     */
    public static void prettyPrints(Jukebox music){
        System.out.println("Jukebox of " + music.jukebox.size() + " songs starts playing...");
        System.out.println("The simulation took " + music.totalTime() + " second/s");
        System.out.println("Number of simulations run: " + SIMULATION_ITERATIONS);
        System.out.println("Total number of songs played: " + music.totalSongs());
        System.out.println("Average number of songs played per simulation to get duplicate: "
                + music.averageNumberOfSongs());
        System.out.println("The most played song was: " + music.mostPlayedSong());
        System.out.println("All songs alphabetically from artist \"" + MOST_PLAYED_ARTIST + "\": ");
        music.alphabeticalSorting();
    }


    public static void main(String[] args) throws FileNotFoundException {
        Jukebox music = new Jukebox(args[0], Integer.parseInt(args[1]));
        prettyPrints(music);
    }
}
