package jukebox;

/**
 * @author: Alex Iacob ai9388@rit.edu
 *
 */
public class Song implements Comparable <Song>{
    /**
     * declaring private variables
     */
    private String artist;
    private String title;

    /**
     * creating instance of a Song that contains the title and artist
     */
    public Song(String artist, String title ) {
        this.artist = artist;
        this.title = title;
    }


    /**
     * gets the artist of the song
     */
    public String getArtist(){
        return this.artist;
    }


    /**
     * gets the title of the song
     */
    public String getSong(){
        return this.title;
    }


    /**
     * determines whether one song is equal to the other
     * by first validating if the titles are equivalent
     * then if the artists are the same
     */
    @Override
    public boolean equals(Object other){
        if (other instanceof Song){
            Song obj = (Song)other;

            if(this.title.equals(obj.title)){
                return this.artist.equals(obj.artist);
            }else{
                return false;
            }

        }
        return false;
    }


    /**
     * compares current song to another
     * @return int
     */
    @Override
    public int compareTo(Song other) {
        int result = this.artist.compareTo(other.artist);
        if(result == 0){
            result = this.title.compareTo(other.title);
        }
        return result;
    }


    /**
     * creates a unique hash code for each song
     * songs with the same title and artist have the same has code
     * @return hash code integer
     */
    @Override
    public int hashCode(){
        return this.artist.hashCode() + this.title.hashCode();
    }
}
