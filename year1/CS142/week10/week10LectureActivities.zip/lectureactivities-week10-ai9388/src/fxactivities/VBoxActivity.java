package fxactivities;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class VBoxActivity extends Application {
  
    public void start(Stage stage) {
        VBox hbox = new VBox();

        Button top = new Button("top");
        Button center = new Button("center");
        Button bottom = new Button("bottom");

        hbox.getChildren().addAll( top, center, bottom);

        Scene scene = new Scene(hbox);
        stage.setScene(scene);
        stage.show();

    }
}