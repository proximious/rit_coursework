package fxactivities;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class HBoxActivity extends Application {
  
    public void start(Stage stage) {
        HBox hbox = new HBox();

        Button right = new Button("right");
        Button middle = new Button("middle");
        Button left = new Button("left");

        hbox.getChildren().addAll( left, middle, right);

        Scene scene = new Scene(hbox);
        stage.setScene(scene);
        stage.show();
    }
}
