package fxactivities;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class BorderPaneActivity extends Application {
    @Override
    public void start(Stage stage) {
         BorderPane pane= new BorderPane ();
         pane.setTop (makeLabel("Zarkov", Color.YELLOW));
         pane.setCenter (makeLabel ("Flash", Color.LIGHTGREEN));
         pane.setLeft (makeLabel ("Dale", Color.PINK));
         pane.setRight (makeLabel ("Ming", Color.PALETURQUOISE));
         pane.setBottom (makeLabel ("Vultan", Color.PEACHPUFF));

        stage.setTitle("BorderPane Activity");
        stage.setScene(new Scene(pane));
        stage.show();
    }

    private static Label makeLabel(String text, Color background) {
        Label label = new Label(text);
        label.setFont(new Font("Arial", 75));
        label.setPadding(new Insets(20));
        label.setBackground(new Background(new BackgroundFill(background,
                CornerRadii.EMPTY, Insets.EMPTY)));
        label.setMaxWidth(Double.MAX_VALUE);
        label.setMaxHeight(Double.MAX_VALUE);
        return label;
    }
}