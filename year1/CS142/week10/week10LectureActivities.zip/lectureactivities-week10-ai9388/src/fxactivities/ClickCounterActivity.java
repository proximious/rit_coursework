package fxactivities;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ClickCounterActivity extends Application {
    private int clickCount;

    @Override
    public void start(Stage stage) throws Exception {
        clickCount = 100;

        StackPane vbox = new StackPane();
        vbox.alignmentProperty().setValue(Pos.CENTER);

        Label counter = new Label(Integer.toString(clickCount));
        counter.setFont(new Font("Courier New", 72));

        Button clicker = new Button("Click Me!");

        clicker.setOnAction(e -> {
            clickCount++;
            counter.setText(Integer.toString(clickCount));
        });

        counter.setMouseTransparent (true);
        vbox.getChildren().addAll( clicker, counter );

        stage.setTitle("Click Counter");
        stage.setScene(new Scene(vbox));
        stage.show();
    }
}
