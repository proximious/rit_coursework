module LectureActivities {
    requires transitive javafx.controls;
    exports fxactivities;
    exports fxexamples;
}