// Starter code for Activity: Observing Napper

package nappers;

import naptimer.NapTimer;
import naptimer.SimpleNapTimer;
import naptimer.NapTimerEvent;
import naptimer.NapTimerObserver;

/**
 * A napper that observes a {@link NapTimer} waiting for a
 * {@link NapTimerEvent} before rousing from its sleep.
 *
 * This is a ConcreteObserver in the ObserverDesignPattern.
 */
public class ObservantNapper implements NapTimerObserver {
    /**
     * Sets the {@link NapTimer NapTimer's} alarm for the specified duration
     * in seconds before going to sleep.
     *
     * @param timer The {@link NapTimer} that will rouse the napper from
     *              sleep when it raises an alarm.
     * @param durationInSeconds The duration of the nap.
     */
    public synchronized void goToSleep (NapTimer timer, int durationInSeconds) throws InterruptedException {
        //TODO: Implement the nappers logic (see slides for details)
        timer.registerObserver(this);
        timer.setAlarm(durationInSeconds);

        try{
            this.wait();
        } catch (InterruptedException ignore){}

        timer.turnOff();
        timer.deregisterObserver(this);
    }

    public static void main (String[] args) throws InterruptedException {
        NapTimer timer = new SimpleNapTimer ();
        Thread thread = new Thread (timer);
        thread.setDaemon (true);
        thread.start ();

        ObservantNapper napper = new ObservantNapper ();
        napper.goToSleep (timer, 5);
    }

    @Override
    public void alarmed(NapTimerEvent event) {

    }
}
