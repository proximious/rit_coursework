package nappers;

import naptimer.NapTimer;
import naptimer.SimpleNapTimer;
import naptimer.NapTimerEvent;
import naptimer.NapTimerObserver;

/**
 * A napper that observes a {@link NapTimer} but snoozes the alarm three times
 * before rousing from sleep.
 *
 * This is a ConcreteObserver in the ObserverDesignPattern.
 */
public class SnoozingNapper implements NapTimerObserver {
    /**
     * Used to count the number of remaining snoozes.
     */
    private int snoozes;

    private NapTimer timer;
 
    /**
     * Sets the {@link NapTimer NapTimer's} alarm for the specified duration
     * in seconds before going to sleep.
     *
     * @param timer The {@link NapTimer} that will rouse the napper from sleep
     *              when it raises an alarm.
     * @param durationInSeconds The duration of the nap.
     */
    public synchronized void goToSleep(NapTimer timer, int durationInSeconds) {
        snoozes = 3;

        timer.registerObserver(this);
        timer.setAlarm(durationInSeconds);
        try {
            wait();
        } catch (InterruptedException ignore) {}

        timer.turnOff();
        timer.deregisterObserver(this);
    }

    @Override
    public synchronized void alarmed(NapTimerEvent event) {
        if(snoozes > 0) {
            timer.setAlarm(5);
            snoozes--;
        } else {
            notify();
        }
    }

    public static void main(String[] args) {
        SimpleNapTimer timer = new SimpleNapTimer();
        Thread thread = new Thread(timer);
        thread.setDaemon(true);
        thread.start();

        SnoozingNapper napper = new SnoozingNapper();
        napper.goToSleep(timer, 5);
    }
}