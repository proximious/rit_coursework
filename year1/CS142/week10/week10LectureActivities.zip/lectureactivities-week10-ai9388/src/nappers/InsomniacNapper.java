// Starter code for Activity: Running a Timer

package nappers;

import naptimer.NapTimer;
import naptimer.SimpleNapTimer;

/**
 * A napper that wakes up every second to see if the alarm on its
 * {@link NapTimer} has been raised yet, and if not, goes back to sleep. An
 * example of polling.
 */
public class InsomniacNapper {

    public void goToSleep (NapTimer timer, 
                           int durationInSeconds) throws InterruptedException {
        timer.setAlarm (durationInSeconds);
        while(!timer.isRinging()){
            System.out.println("Not time yet");
            try{
                Thread.sleep(1234);
            } catch (InterruptedException e){
                System.out.println("Exception is dead");
            }
        }

        System.out.println("The alarm is going off!");
        timer.turnOff();
    }

    /**
     * Creates a new {@link NapTimer} and InsomniacNapper. The sleeper polls
     * to check to see if the alarm has gone off.
     *
     * @param args The
     */
    public static void main(String[] args) throws InterruptedException {
        NapTimer timer = new SimpleNapTimer();
        Thread thread = new Thread (timer);
        thread.setDaemon(true);
        thread.start();

        InsomniacNapper napper = new InsomniacNapper();
        napper.goToSleep(timer, 10);
    }
}