// Starter code for Activity: Event Class.

package naptimer;

public class NapTimerEvent {
    private final NapTimer timer;

    public NapTimerEvent(NapTimer timer) {
        this.timer = timer;
    }

    public NapTimer getNapTimer() {
        return timer;
    }
    
}