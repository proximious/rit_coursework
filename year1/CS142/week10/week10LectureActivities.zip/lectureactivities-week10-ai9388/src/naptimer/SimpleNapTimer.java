// Starter code for Activities: Manage Observers and Main

package naptimer;

import java.util.HashSet;
import java.util.Set;

public class SimpleNapTimer implements NapTimer, Runnable {
    /**
     * The time at which the alarm will be raised (or 0 if there is no alarm).
     */
    private long alarmTime;

    /**
     * Flag that indicates whether or not the alarm is currently ringing.
     */
    private boolean ringing;

    /**
     * The SimpleNapTimer is the Subject in the Observer Design Pattern.
     * {@link NapTimerObserver} defines the interface for Observers. This set
     * keeps track of the registered Observers.
     */
    private final Set<NapTimerObserver> registeredListeners;

    /**
     * Creates a new {@link SimpleNapTimer}.
     */
    public SimpleNapTimer() {
        registeredListeners = new HashSet<>();
        turnOff();
    }

    public synchronized boolean isRinging () {
        return ringing;
    }

    public synchronized void turnOff () {
        ringing = false;
        alarmTime = 0;
        notify();
    }

    public synchronized void setAlarm (int delayInSeconds) {
        alarmTime = System.currentTimeMillis() + (delayInSeconds * 1000);
        ringing = false;
        notify();
    }

    /**
     * The {@link SimpleNapTimer SimpleNapTimer's} standard loop. If no alarm has been
     * set, it waits for the alarm to be set. Otherwise, it counts down by
     * seconds until the delay elapses. Once the delay time elapses, the alarm
     * is raised and any observers are notified.
     */
    @Override
    public synchronized void run () {
        while (true) {
            // waits until the alarm has actually been set
            while (ringing || alarmTime <= System.currentTimeMillis()) {
                try { 
                    wait(); 
                } catch (InterruptedException ignore) {}
            }

            // waits until the alarm time has expired
            while (System.currentTimeMillis() < alarmTime) {
                try { 
                    Thread.sleep (1000); 
                } catch (InterruptedException ignore) {}
            }

            // if the alarm has been set (as opposed to turned off), raises
            // the alarm
            if (alarmTime > 0) {
                // set the alarm to ring
                ringing = true;

                NapTimerEvent event = new NapTimerEvent(this);
                for(NapTimerObserver listener : registeredListeners) {
                    listener.alarmed(event);
                }
            }
        }
    }
    public void registerObserver(NapTimerObserver listener) {
        registeredListeners.add(listener);
    }

    public void deregisterObserver(NapTimerObserver listener) {
        registeredListeners.remove(listener);
    }


}
  