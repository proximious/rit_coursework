// Starter code for Activity: NapTimer

package naptimer;

public interface NapTimer extends Runnable {
    public void turnOff();
    public int seconds = 0;
    public void setAlarm(int seconds);
    public boolean isRinging();
    public void registerObserver(NapTimerObserver listener);
    public void deregisterObserver(NapTimerObserver listener);
}