// Starter code for Activity: Observer Interface

package naptimer;

public interface NapTimerObserver {
    public void alarmed(NapTimerEvent event);
}