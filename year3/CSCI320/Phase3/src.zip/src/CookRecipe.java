public class CookRecipe {

}
