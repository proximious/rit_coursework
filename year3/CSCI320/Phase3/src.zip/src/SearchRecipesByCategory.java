public class SearchRecipesByCategory {
}
