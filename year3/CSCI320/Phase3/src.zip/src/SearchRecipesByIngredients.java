public class SearchRecipesByIngredients {
}
