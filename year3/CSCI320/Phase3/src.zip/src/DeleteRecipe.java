public class DeleteRecipe {

}
