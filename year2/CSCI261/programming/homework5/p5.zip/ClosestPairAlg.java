import java.util.*;

public abstract class ClosestPairAlg {

    public abstract Triple closestPair(Point[] P);
}
			      
