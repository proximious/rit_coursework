package com.webcheckers.model;

/**
 * Enum for piece types SINGLE, and KING
 */
public enum PieceType {SINGLE, KING}