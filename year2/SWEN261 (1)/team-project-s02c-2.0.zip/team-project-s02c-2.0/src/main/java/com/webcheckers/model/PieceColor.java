package com.webcheckers.model;

/**
 * Enum for the piece colors RED and WHITE
 */
public enum PieceColor {RED, WHITE}
