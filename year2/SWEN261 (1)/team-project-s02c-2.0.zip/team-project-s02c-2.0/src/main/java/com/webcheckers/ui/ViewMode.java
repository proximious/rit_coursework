package com.webcheckers.ui;

/**
 * Enum for the types PLAY, SPECTATOR, REPLAY
 */
public enum ViewMode {PLAY, SPECTATOR, REPLAY}
