package com.webcheckers.model;

/**
 * Enum for the space colors on the board. Colors are BLACK and WHITE
 */
public enum SpaceColor {BLACK, WHITE};
