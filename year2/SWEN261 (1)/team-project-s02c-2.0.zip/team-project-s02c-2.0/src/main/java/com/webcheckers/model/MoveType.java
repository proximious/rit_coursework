package com.webcheckers.model;

/**
 * Enum for Move types.
 */
public enum MoveType {SIMPLE_MOVE,SIMPLE_MOVE_BACK,JUMP_MOVE,JUMP_MOVE_BACK, KING_PIECE}
