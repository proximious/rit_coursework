
function Review_of_Linear_Indexing_into_Matrices()

    % Initialize some channels for a matrix:
    
    numbers             = 11 : 16 ;
    channel_1           = reshape( numbers, 2, 3 );
    
    numbers             = 21 : 26 ;
    channel_2           = reshape( numbers, 2, 3 );

    numbers             = 31 : 36 ;
    channel_3           = reshape( numbers, 2, 3 );

    % Put the matrix together:
    my_image            = channel_1
    my_image(:,:,2)     = channel_2
    my_image(:,:,3)     = channel_3
    
    % Print the image that we built up:
    my_image

    % Now, test the indexing methods:
    
    disp('Guess this value, then hit return:  my_image( 3 )' );
    pause();
    my_image( 3 )
    
    disp('Guess this value, then hit return:  my_image( 10 )' );
    pause();
    my_image( 10 )
    
    disp('Guess this value, then hit return:  my_image( 17 )' );
    pause();
    my_image( 17 )
end

