
function fix_muskan_image_v11( fn_in )
% Mung Muskan into an image with better lighting.
% 
% We need to increase the contrast in her hair.
% We need to maintain the contrast in her face, without making her nose too bright.
%
vers = get_fn_version( mfilename() );

    if nargin < 1
        fn_in = 'Muskan.jpg';
    end


    % Crop out Muskan's face:
    crop_xs                     = [ 127 651 ];
    crop_ys                     = [ 320 831 ];

    
    % Read in the image:
    im_rgb                      = im2double(imread( fn_in ));
    
    % Do the crop of the original image:
    % Write this out for power points:
    im_cropped                  = im_rgb( crop_ys(1):crop_ys(2), crop_xs(1):crop_xs(2), : );    
    imwrite( im_cropped, 'Muskan_Cropped_Original.jpg', 'JPEG', 'Quality', 95 );
    

    %
    %  1. CONVERT TO HSV
    %  2. Fix the values
    %  3. Convert Back to RGB....
    %
    im_hsv                      = rgb2hsv( im_rgb );
    im_v                        = im_hsv(:,:,3);
    
    % Manually segment the image into dark, middle, and bright regions:
    b_dark                      = im_v <= 0.2;                  % Hair and suit
    b_midl                      = im_v > 0.2 & im_v <= 0.55;    % Eyes, lips, neck
    b_high                      = im_v > 0.55;                  % Everything else.
    
    % Get each region:
    im_dark                     = zeros( size(im_v) );
    im_dark(b_dark)             = im_v( b_dark );

    im_midl                     = zeros( size(im_v) );
    im_midl(b_midl)             = im_v( b_midl );
    
    im_high                     = zeros( size(im_v) );
    im_high(b_high)             = im_v( b_high );
    
    
    % Now re-map the pixels in the dark region as follows:
    % 1.  Clip off the bottom 0.05.
    %     This puts the dark pixels in the range [0, 0.15 ]
    % 2.  Multiply by two:
    %
    % This stretches out and expands the contrast in the dark
    % regions so that they are in the range [ 0, 0.45 ]
    %
    im_2                        = im_dark - 0.05;
    im_2(im_2<0)                = 0.0;                  % Clip negative values.
    im_dark                     = im_2 * 3.0;
    
    % The mid-level pixels are in the range ( 0.2,  0.5 ] 
    % 
    % We want to use dynamic ranging here to map them 
    % to the range ( 0.3, 0.7 );
    old_min         = 0.2;
    old_max         = 0.55;
    new_min         = 0.45;
    new_max         = 0.85;
    im_midl         = (im_midl - old_min) ./ (old_max - old_min) ...
                                          .* (new_max - new_min) + new_min;
    

    %
    % The brightest part of the image are in the range: 
    % (0.5 to 1.0].  
    %
    % Map them to (0.7,1.0].
    %
    % 
    old_min         = 0.55;
    old_max         = 1.0;
    new_min         = 0.85;
    new_max         = 1.0;
    im_high         = (im_high - old_min) ./ (old_max - old_min) ...
                                          .* (new_max - new_min) + new_min;

    %
    %  Merge the three regions back together again:
    %
    im_merged_values                   = im_dark;
    im_merged_values( b_midl )         = im_midl( b_midl );
    im_merged_values( b_high )         = im_high( b_high );

    % Add the value back into the hue and saturation:
    im_hsv(:,:,3)               = im_merged_values;

    % Enhance the color saturation:
    im_sat                      = im_hsv(:,:,2);
    im_sat                      = im_sat * 1.15;
    im_sat(im_sat>1.0)          = 1.0;              % Clip to max value.
    im_hsv(:,:,2)               = im_sat;
    

    % Convert back into RGB:
    im_rgb_new                  = hsv2rgb( im_hsv );
    
    % Do the crop
    im_cropped                  = im_rgb_new( crop_ys(1):crop_ys(2), crop_xs(1):crop_xs(2), : );
    
    fn_out = sprintf('Muskan_heavily_processed%s.jpg', vers); 
    imwrite( im_cropped, fn_out, 'JPEG', 'Quality', 95 );
    
    whos im_cropped
    
    
    zoom_figure();
    imagesc( im_cropped );
    axis image;
    axis off;
    
    
    %
    %  Show the transformations:
    %
    zoom_figure( [1800 1024] );
    
    % Show Original values
    subplot( 2, 2, 1 );
    imhist( im_v );   
    title('Original Histogram', 'FontSize', 24 );
    set(gca,'FontSize', 18 );
    
    % Show transformation curve for the values:
    subplot( 2, 2, 2 );
    input_pts  = [ 0.05, 0.20, 0.55, 1.0 ];
    output_pts = [ 0.0,  0.45, 0.85, 1.0 ];
    plot( input_pts, output_pts, 'b-', 'Linewidth', 3 );
    axis( [0 1 0 1] );
    axis square;
    grid on;
    set(gca,'FontSize', 18 );
    set(gca,'XTick', [0 : 0.2 : 1.0 ] );
    title('Transformation Curve', 'FontSize', 24 );
    xlabel('Input Value', 'FontSize', 20 );
    ylabel('Output Value', 'FontSize', 20 );
    
    
    % Show Resulting values
    subplot( 2, 2, 4 );
    imhist( im_hsv(:,:,3) );   
    title('Resulting Histogram', 'FontSize', 24 );
    set(gca,'FontSize', 18 );

