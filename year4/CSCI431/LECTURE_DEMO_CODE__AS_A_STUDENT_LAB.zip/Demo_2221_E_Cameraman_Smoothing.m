
function Demo_2221_E_Cameraman_Smoothing( )

    %
    %  What does this do?
    %
    %  Look at the filter coefficients that result:
    %  The Gaussian filter gives more weight to the center of the neighborhood.
    % 
    %  NOTICE The difference between the center value, and the values on the edge:
    %
    filter_with_weights = fspecial( 'Gaussian', 5, 2 )
    
    im_input    = im2double( imread( 'cameraman.tif' ) );
    
    im_output   = imfilter( im_input, filter_with_weights, 'same', 'replicate' );
    
    % Make a big figure:
    zoom_figure( );
    
    % Show original input: 
    subplot( 1, 2, 1 );
    imshow( im_input );
    
    subplot( 1, 2, 2 );
    imshow( im_output );
    
end