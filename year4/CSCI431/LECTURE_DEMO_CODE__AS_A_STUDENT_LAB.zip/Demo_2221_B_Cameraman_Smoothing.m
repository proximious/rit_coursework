
function Demo_2221_B_Cameraman_Smoothing( )

    %
    %  Is this any different from Demo_2221_A??
    %
    filter_with_weights = ones( 3 ) / 9;

    
    im_input    = im2double( imread( 'cameraman.tif' ) );
    
    im_output   = imfilter( im_input, filter_with_weights, 'same', 'replicate' );
    
    % Make a big figure:
    zoom_figure( );
    
    % Show original input: 
    subplot( 1, 2, 1 );
    imshow( im_input );
    
    subplot( 1, 2, 2 );
    imshow( im_output );
    
end