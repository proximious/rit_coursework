
function Demo_2221_G_Cameraman_Edges( )


    % Why does the following filter normalize by 8?

    filter_with_weights = [ -1,  0, +1 ; 
                            -2,  0, +2 ;
                            -1,  0, +1 ] / 8;
    
    im_input    = im2double( imread( 'cameraman.tif' ) );
    
    im_output   = imfilter( im_input, filter_with_weights, 'same', 'replicate' );
    
    % Make a big figure:
    zoom_figure( );
    
    % Show original input: 
    subplot( 1, 2, 1 );
    imagesc( im_input );
    axis image;
    
    subplot( 1, 2, 2 );
    imagesc( im_output );
    axis image;
    colormap( gray(256) );
    
end