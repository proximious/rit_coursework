
function Demo_2221_K_Cameraman_Edge_Directions( )
FS = 40;

    % Why does the following filter normalize by 8?

    vert_gradient_sobel = [ -1, -2, -1 ; 
                             0,  0,  0 ;
                            +1, +2, +1 ] / 8;
                        
    horz_gradient_sobel = [ -1,  0, +1 ; 
                            -2,  0, +2 ;
                            -1,  0, +1 ] / 8;
    
    im_input    = im2double( imread( 'cameraman.tif' ) );
    
    edg_dy      = imfilter( im_input, vert_gradient_sobel, 'same', 'replicate' );
    edg_dx      = imfilter( im_input, horz_gradient_sobel, 'same', 'replicate' );
    
    edg_angles  = atan2( -edg_dy, edg_dx ) * 180 / pi;
    
    
    % Make a big figure:
    zoom_figure( [1800 1020] );

    % Show original input: 
    subplot( 2, 2, 1 );
    imagesc( im_input );
    axis image;
    title('Original Image', 'Fontsize', FS );
    colorbar;
    
    subplot( 2, 2, 2 );
    imagesc( edg_dy );
    axis image;
    colormap( gray(256) );
    title('Gradient Amount in Y direction', 'Fontsize', FS );
    colorbar;
    caxis( [-0.5 0.5]);     % Change the color axis to known levels.
    xlabel('Notice that edge Amount can be negative.', 'FontSize', FS-10 );
    
    
    subplot( 2, 2, 3 );
    imagesc( edg_dx );
    axis image;
    colormap( gray(256) );
    title('Gradient Amount in X direction', 'Fontsize', FS );
    colorbar;
    caxis( [-0.5 0.5]);
    xlabel('Notice that edge Amount can be negative.', 'FontSize', FS-10 );
    
    subplot( 2, 2, 4 );
    imagesc( edg_angles );
    axis image;
    
    % The HSV colormap has the nice property that the top and bottom
    % are the same color.  The color wraps around.
    %
    % HSV stands for "hue saturation and value"
    colormap( hsv(256) );

    title('Edge Gradient DIRECTION' , 'Fontsize', FS );
    xlabel('The direction -- regardless of edge amount', 'FontSize', FS-10 );
    colorbar;
end
