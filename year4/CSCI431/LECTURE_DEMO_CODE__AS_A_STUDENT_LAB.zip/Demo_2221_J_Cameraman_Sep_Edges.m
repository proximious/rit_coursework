
function Demo_2221_J_Cameraman_Sep_Edges( )
FS = 32;

    % Why does the following filter normalize by 8?

    vert_gradient_sobel = [ -1, -2, -1 ; 
                             0,  0,  0 ;
                            +1, +2, +1 ] / 8;
                        
    horz_gradient_sobel = [ -1,  0, +1 ; 
                            -2,  0, +2 ;
                            -1,  0, +1 ] / 8;
    
    im_input    = im2double( imread( 'cameraman.tif' ) );
    
    edg_dy   = imfilter( im_input, vert_gradient_sobel, 'same', 'replicate' );
    edg_dx   = imfilter( im_input, horz_gradient_sobel, 'same', 'replicate' );
    
    edg_mag  = sqrt( edg_dx.^2 + edg_dy.^2 );
    
    
    % Make a big figure:
    zoom_figure( [1800 1020] );

    % Show original input: 
    subplot( 2, 2, 1 );
    imagesc( im_input );
    axis image;
    title('Original Image', 'Fontsize', FS );
    
    subplot( 2, 2, 2 );
    imagesc( edg_dy );
    axis image;
    colormap( gray(256) );
    title('Gradient Amount in Y direction', 'Fontsize', FS );
    colorbar;
    caxis( [-0.5 0.5]);     % Change the color axis to known levels.
    xlabel('Notice that edge Amount can be negative.', 'FontSize', FS-10 );
    
    
    subplot( 2, 2, 3 );
    imagesc( edg_dx );
    axis image;
    colormap( gray(256) );
    title('Gradient Amount in X direction', 'Fontsize', FS );
    colorbar;
    caxis( [-0.5 0.5]);
    xlabel('Notice that edge Amount can be negative.', 'FontSize', FS-10 );
    
    subplot( 2, 2, 4 );
    imagesc( edg_mag );
    axis image;
    colormap( gray(256) );
    title('Edge Gradient Magnitude Overall', 'Fontsize', FS );
    xlabel('Magnitude is Edge Amount, regardless of direction.', 'FontSize', FS-10 );
end