
function Demo_2221_C_Cameraman_Smoothing( )

    %
    %  What does this do?
    %
    filter_with_weights = ones( 7 ) / 49;
    
    
    im_input    = im2double( imread( 'cameraman.tif' ) );
    
    im_output   = imfilter( im_input, filter_with_weights, 'same', 'replicate' );
    
    % Make a big figure:
    zoom_figure( );
    
    % Show original input: 
    subplot( 1, 2, 1 );
    imshow( im_input );
    
    subplot( 1, 2, 2 );
    imshow( im_output );
    
end