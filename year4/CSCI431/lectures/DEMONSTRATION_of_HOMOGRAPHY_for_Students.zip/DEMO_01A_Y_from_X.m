function DEMO_01A_Y_from_X()
%
%  This is an example of THE HARD WAY.
% 
%  We know Y = mx + 1.
%
% x points to find y at:
x_values = [ ...
    0.90  1.30  1.90  2.52  1.81  2.87  4.11  5.68  6.97  8.05  8.42  7.32  ...
          6.51  6.12  5.43  5.03  4.32  3.58  4.64  5.26  5.96  6.67  7.55 ;
];

FS = 22;

    % Set the slope to 1/4:
    m  = 1/4;

    % Set the Y intercept to 3:
    b  = 3;


    Y = m * x_values + b; 
    
    zoom_figure( [1024 768] );
    plot( x_values(:), Y(:), 'ks', 'MarkerSize', 15, 'MarkerFaceColor', 'b' );
    grid on;
    axis( [0 10 0 10]);
    xlabel( 'X Sample points ', 'FontSize',  FS );
    ylabel( 'Y Value Computed ', 'FontSize', FS );
    
    title('How do you model this line?  Often, Y = mX + b', 'FontSize', FS );

end

