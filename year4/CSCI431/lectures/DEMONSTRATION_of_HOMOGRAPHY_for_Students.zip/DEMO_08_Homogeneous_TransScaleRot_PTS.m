function DEMO_08_Homogeneous_TransScaleRot_PTS()
%  Combine translation, scaling, and rotation.
%
%  Demonstrate scaling of points:
%
MS  =  5;                               % Marker Size.
FS  = 22;                               % Font size for labels and titles.

    xy_pts  = house_pts();              % Loaded from a pre-defined set of points.

    %
    %   CONVERT XY POINTS INTO HOMOGENEOUS POINTS ...
    %   by adding a row of one's under it:
    %
    xyh_pts     = [ xy_pts ; ... 
                    ones(1,size(xy_pts,2) ) ];

    Scl     = [ (1/3)   0    0 ;
                  0   (1/3)  0 ;
                  0     0    1 ];
              
    Trans   = [ 1  0   4.5 ; 
                0  1   2.5 ;
                0  0     1 ];
    
    Rxyz    = RotMatZ( 30 * pi / 180 );
    
    ScaleRotateTranslate    = Trans * Rxyz * Scl;
    uv_pts                  = ScaleRotateTranslate * xyh_pts;  

    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'ks-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [0 6 0 6]);
    xlabel( 'X ', 'FontSize', FS );
    ylabel( 'Y ', 'FontSize', FS );
    title( 'Scaling, Rotation, and Translation Combined ', 'FontSize', FS );
    
    hold on;
    
    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );    
    legend( { 'Original Points ', 'Transformed Points ' }, ...
              'FontSize', FS, ...
              'Location', 'NorthWest' );

end
