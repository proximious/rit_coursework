function DEMO_10_TransScaleRot_PTS()
%  SOME POINTS:
MS = 4;

    xy_pts     = house_pts();
    xyh_pts     = [ xy_pts ; ... 
                    ones(1,size(xy_pts,2) ) ];

    Scl     = [ (1/3)   0    0 ;
                  0   (1/3)  0 ;
                  0     0    1 ];
              
    Trans   = [ 1  0   1.5 ; 
                0  1     4 ;
                0  0     1 ];
    
    Rxyz        = RotMatZ( 30 * pi / 180 );
    
    disp('The key here is that you can combine the matrices:');
    
    RotSclTrans = Rxyz * Scl * Trans
    uv_pts      = RotSclTrans * xyh_pts;

    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'bs-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [-2 6 -2 6]);
    xlabel( 'X ', 'FontSize', 22 );
    ylabel( 'Y ', 'FontSize', 22 );
    
    hold on;
    
    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );
    
    legend( { 'Original Points ', 'Transformed Points ' }, 'FontSize', 32, 'Location', 'NorthEast' );

end


