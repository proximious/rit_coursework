function DEMO_06_Homogeneous_Trans_PTS()

%  Demonstrate scaling of points:
MS  =  5;                               % Marker Size.
FS  = 22;                               % Font size for labels and titles.

    xy_pts  = house_pts();              % Loaded from a pre-defined set of points.

    %
    %   CONVERT XY POINTS INTO HOMOGENEOUS POINTS ...
    %   by adding a row of one's under it:
    %
    xyH_pts     = [ xy_pts ; ... 
                    ones(1,size(xy_pts,2) ) ];

    Scl     = 2.0*eye(2);
    Trans   = [ 3.5 ; 
                1.0 ];
    
            
    %
    %   BUILD THE TRANSLATION MATRIX WITH THE X and Y TRANSLATION AMOUNTS:
    %
    fprintf('BUILD THE TRANSLATION MATRIX WITH THE X and Y TRANSLATION AMOUNTS:\n');
    Scaling_Matrix      = [ Scl(1,1),  Scl(1,2), 0 ; 
                            Scl(2,1),  Scl(2,2), 0 ;
                            0,         0,        1 ];
                        
    Translation_Matrix  = [ 1,  0, Trans(1) ; 
                            0,  1, Trans(2) ;
                            0,  0, 1        ];
                        
    ScalingAndTranslationMatrix = Translation_Matrix * Scaling_Matrix
                       
    
    % TBK Routine:
    print_mat( ScalingAndTranslationMatrix, 1, 'ScalingAndTranslationMatrix', 2 )
            
    
    %  SHORT FOR:
    %
    % uv = Translation_Matrix * Scaling_Matrix * xyH_pts
    %
    uv_pts  = ScalingAndTranslationMatrix * xyH_pts;

    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'ks-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [0 10 0 10]);
    xlabel( 'X Value ',  'FontSize', FS );
    ylabel( 'Y Value  ', 'FontSize', FS );
    title(  'Scaled and Translated -- the Homogeneous Way.', 'FontSize', FS );
    
    hold on;

    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );
    
    legend( { 'Original Points ', 'Transformed Points ' }, ...
            'FontSize', FS, ...
            'Location', 'NorthWest' );

end


