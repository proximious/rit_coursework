function DEMO_16_blkproc_exp()

        I = rgb2gray( imread('football.jpg') );
        dims = size( I );
        
        fun = @dct2;
        J = blkproc(I,[8 8],fun);
        
        figure;
        imagesc( I );
        colormap(gray);
        title('FOOTBALL - Spacial ', 'FontSize', 22 );
        
        figure;
        imagesc(J);
        colormap(gray);
        
        fun         = @unzz;
        unzigged    = blkproc( J,[8 8], fun );
        imagesc( unzigged );
        colormap(gray);
  
end

function im_out = unzz( im_in )

    im_tr   = im_in.';        % Transpose.
    im_out  = im_tr(:).';     % Row vectorized.
    
end
