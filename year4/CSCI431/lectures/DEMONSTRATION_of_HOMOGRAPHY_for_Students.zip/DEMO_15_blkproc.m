function DEMO_15_blkproc()

        I = rgb2gray( imread('football.jpg') );
        dims = size( I );
        
        fun = @dct2;
        J = blkproc(I,[8 8],fun);
        
        figure;
        imagesc( I );
        colormap(gray);
        title('FOOTBALL - Spacial ', 'FontSize', 22 );

%         figure;
%         imagesc(J);
%         colormap(gray);
        
        %
        %  EXTRACT THE FIRST EDGE DCT COEFFICIENTS, AND ADD THEM UP.
        %  Use the absolute values to be sure that they don't cancel each
        %  other out.  Negative amounts indicate coefs that are in the
        %  opposite direction.
        %
        coef_12     = abs( J( 1:8:end, 2:8:end ) );
        coef_22     = abs( J( 2:8:end, 2:8:end ) );
        coef_21     = abs( J( 2:8:end, 1:8:end ) );
        
        coefs_avg   = coef_12 + 2*coef_22 + coef_21;
        

        res_im      = imresize( coefs_avg, dims, 'Nearest' );
        figure;
        imagesc( res_im );
        colormap(gray);
  
end

