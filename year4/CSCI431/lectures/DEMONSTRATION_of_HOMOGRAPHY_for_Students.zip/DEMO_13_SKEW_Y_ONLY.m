function DEMO_13_SKEW_Y_ONLY()
%  SOME POINTS:
MS  =  5;                               % Marker Size.
FS  = 22;                               % Font size for labels and titles.

    xy_pts      = house_pts();

    xyh_pts     = [ xy_pts ; ... 
                    ones(1,size(xy_pts,2) ) ];

    SKEW        = [ 0.00,    0.30  ];        % A little skew does a lot

    SkewXform   = [   1,        0,         0 ;
                      0,        1,         0 ;
                    SKEW(1),  SKEW(2),   1-sum(SKEW) ];  

    uv_pts      = SkewXform * xyh_pts;       % Translate and skew only.

    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'ks-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [0 10 0 6 ]);
    xlabel( 'X ',  'FontSize', FS );
    ylabel( 'Y ',  'FontSize', FS );
    
    hold on;

    %
    %  COMPENSATE FOR THE MAGNITUDE CHANGES OF THE HOMOGENEOUS COORDINATES:
    %
    fprintf('THE KEY TO USING SKEWING IS YOU MUST COMPENSATE BY THE CHANGE IN HOMOGENEOUS SCALE:\n');
    uv_pts  = uv_pts ./ repmat( uv_pts(3,:), 3, 1 );
    
    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );
    
    QRST = uv_pts / xyh_pts
    
    legend( { 'Original Points ', 'Transformed Points ' }, ... 
              'FontSize', FS, 'Location', 'North' );
    title('Skew Included in Transformation ', 'FontSize', FS );

end


