function DEMO_07_Homogeneous_TransScale_PTS()
%  SOME POINTS:

MS  =  5;                               % Marker Size.
FS  = 22;                               % Font size for labels and titles.

    xy_pts      = house_pts();

    xyh_pts     = [ xy_pts ; ... 
                    ones(1,size(xy_pts,2) ) ];

    Scl     = 0.5 * eye(2);
    Trans   = [ 1.5 ; ...
                4.0 ];
    
    SclTrans = [  Scl , Trans ; ...
                  0  0      1 ]
    
    uv_pts  = SclTrans * xyh_pts; 


    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'ks-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [0 10 0 10]);
    xlabel( 'X ', 'FontSize', FS );
    ylabel( 'Y ', 'FontSize', FS );
    title(  'House Shrunk and Translated using Homogeneous Transforms.', ...
        'FontSize', FS );
    
    hold on;
    
    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );
    
    legend( { 'Original Points ', 'Transformed Points ' }, ...
        'FontSize', FS, 'Location', 'NorthEast' );

end
