
function DEMO_21_SOLVING_FOR_TransScaleRot_PTS_w_cp2transform()
%  SOME POINTS:
MS  =  5;                               % Marker Size.
FS  = 22;                               % Font size for labels and titles.

    xy_pts      = house_pts();

    xyh_pts     = [ xy_pts ; ... 
                    ones(1,size(xy_pts,2) ) ];

    Scl     = 0.5 * eye(2);
    Trans   = [ 5 ; 
                4 ];

    Rxyz    = RotMatZ( 30 * pi / 180 );

    SclTrans = [  Scl , Trans ; ...
                  0  0      1 ];
          
    RotSclTrans = Rxyz * SclTrans;

    uv_pts      = RotSclTrans * xyh_pts; 

    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'ks-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [0 10 0 10]);
    xlabel( 'X ', 'FontSize', 22 );
    ylabel( 'Y ', 'FontSize', 22 );
    
    hold on;
    
    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );
    legend( { 'Original Points ', 'Transformed Points ' }, 'FontSize', 32, 'Location', 'NorthEast' );
    

    %
    %  SOLVE FOR THE MATRIX TRANSFORMATION:
    %
    fprintf('\nMatlab gives: \n');
    QRST    = uv_pts / xyh_pts
    

    fprintf('\ncp2tform gives:\n');
    GUESS   = cp2tform( uv_pts(1:2,:).', xyh_pts(1:2,:).', 'projective' );
%     GUESS.tdata.Tinv
    GUESS.tdata.Tinv.'
    
end


