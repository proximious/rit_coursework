function DEMO_14_blkproc()

        I = imread('cameraman.tif');
        
        fun = @dct2;
        J = blkproc(I,[8 8],fun);
        imagesc(J);
        colormap(hot);
 

end
