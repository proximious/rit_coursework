function DEMO_01B_Y_from_X()
%  We know Y = mx + 1.
%
%  We can write this as a matrix as:
% 
% Y = [m b] * [ x1 1 ;
%               x2 1 ;
%               x3 1 ].... 

% x points to find y at:
x_values = [ ...
    0.90  1.30  1.90  2.52  1.81  2.87  4.11  5.68  6.97  8.05  8.42  7.32  ...
          6.51  6.12  5.43  5.03  4.32  3.58  4.64  5.26  5.96  6.67  7.55 ;
];
FS = 22;

    % Here is the equation of my line:
    % Slope is first component, 
    % Y-Intercept is second component.
    MB  = [ 1/4, 3 ]        
    
    % Form the X matrix:
    X   = [ x_values  ;  ...
            ones(1,length(x_values)) ];
        
    % This simply adds a line of 1's along the bottom:
    %
    %   X = [ ...
    %     0.9  1.3  1.9  2.5  1.8  2.9  4.1  5.7  7.0  8.1  8.4  7.3  6.5  6.1  5.4  5.0  4.3  3.6  4.6  5.3  6.0  6.7  7.5 ;
    %     1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0  1.0 ;
    %   ];
    %
    % We do this because it makes our lives easier.

    %  Remember the equation of a line:
    %
    %  Y = M * X + B?
    %  
    %  Now, in linear algebra, we can write:
    %

    Y = MB * X 
    
    zoom_figure( [1024 768] );
    plot( x_values(:), Y(:), 'ks', 'MarkerSize', 15, 'MarkerFaceColor', 'b' );
    grid on;
    axis( [0 10 0 10]);
    xlabel( 'X Sample points ', 'FontSize', 22 );
    ylabel( 'Y Value Computed ', 'FontSize', 22 );
    
    
    title('The easy way to model this is with homogeneous coordinates: Y = M * X', 'FontSize', FS );

    %
    %  NOW -- SUPPOSE YOU DID NOT KNOW MB!!
    %
    %  WE KNOW THAT:
    %  
    %  Y = MB * X
    %
    %  BEING SILLY, WE WISH WE COULD WRITE:
    %
    %  Y / X = MB
    %
    
    GUESS_FOR_MB = Y / X

end


