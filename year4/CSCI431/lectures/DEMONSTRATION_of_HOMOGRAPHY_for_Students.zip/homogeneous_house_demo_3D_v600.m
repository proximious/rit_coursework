function homogeneous_house_demo_3D_v600() 
% Demo of using Homogeneous Coords to translate,
% scale, rotate, etc... 
%
% Dr. Thomas B. Kinsman,
% Oct 31, 2017
% Happy Halloween.
%
% NOTE THAT ROTATION IS ALWAYS AROUND THE ORIGIN.
% So, to just twist the house, we:
%
% A.  Translate the origin to the center of the house.
%
% B.  Do the rotation.
%
% C.  Translate the origin back to the bottom left 
%     with respect to the house.
%
% The same sort of argument goes for shrinking things.
%
% Remember: 
% For this example, data is arranged in rows.
% For example, the rows of the house_xy matrix is a row of x values,
% then a row of y values, then a row of 1's.
%
% For situations where x values are a column on the left, then the y values are a column in the middle,
% a the right hand side is a column of 1's --> the matrices are post-multiplied, many of the matrices 
% are transposed, and the order of multiplications is left-for-right.
%

    hxyz        = house_pts_3D();
    dims        = size(hxyz);
    hxyz(4,:)   = ones(1,dims(2));
    
    plot3( hxyz(1,:), hxyz(2,:), hxyz(3,:), 'k-' );
    axis([-3 10 -3 10 -3 10]);
    figure( gcf );
    pause(2);
    
    grid on ;
    box on;
    
    view(2);
    
    % Create a matrix to translate the center of the house,
    % at (6,3) to the origin:
    TranslationA = [ 1 0 0 -1.5 ;
                     0 1 0 -1.5 ;
                     0 0 1  0 ;
                     0 0 0  1 ];
    new_pts = TranslationA * hxyz;
    hold on;
    plot3( new_pts(1,:), new_pts(2,:), new_pts(3,:), 'b-' );
    
    axis([-5 5 -5 5 -5 5 ]);
    grid on;
    figure( gcf );
    pause(2);
    
    % Create a matrix to scale all the points in by a 
    % factor of 0.5.
    %
    % (Tiny houses are in fashion.)
    %
    ScaleB = [ 1/2  0   0   0 ;
                0  1/2  0   0 ;
                0   0   1/2 0 ;
                0   0   0   1 ];
    new_pts = ScaleB * TranslationA * hxyz;
    plot3( new_pts(1,:), new_pts(2,:), new_pts(3,:), 'r-', 'LineWidth', 4 );
    
    axis([-5 5 -5 5 -5 5]);
    figure( gcf );
    pause(2);
    
    % Create a matrix to rotate the points by some angle degrees.
    %
    theta   = 37;
    RotateA = [ cosd(theta)  -sind(theta)  0  0 ;
                sind(theta)   cosd(theta)  0  0 ;
                     0             0       1  0 ;
                     0             0       0  1 ];
    new_pts = RotateA * ScaleB * TranslationA * hxyz;
    plot3( new_pts(1,:), new_pts(2,:), new_pts(3,:), 'm-', 'LineWidth', 4 );
    
    axis([-3 10 -3 10 -3 10]);
    figure( gcf );
    pause(2);
    
    
    % Create a matrix to move the house back up to be 
    % centered at the point (4,6)
    %
    % Create a matrix to translate the center of the house,
    % at (6,3) to the origin:
    TranslationB = [ 1 0 0 +1.5 ;
                     0 1 0 +1.5 ;
                     0 0 1  0 ;
                     0 0 0  1 ];
    new_pts = TranslationB * RotateA * ScaleB * TranslationA * hxyz;
    plot3( new_pts(1,:), new_pts(2,:), new_pts(3,:), 'g-', 'LineWidth', 3 );
    
    axis equal;                     % Make the units square.
    axis([-10 10 -10 10 -10 10]*0.5);
    grid on;
    box on;
    
    figure( gcf );
    pause(2);
    
    fprintf('\n');
    fprintf('The four operations can all be done with one combined matrix:\n\n');
    CombinedMatrix = TranslationB * RotateA * ScaleB * TranslationA
    
    %
    %  We can solve for that matrix, if we only knew the input points and 
    %  the resulting points:
    % 
    %         new_pts = MM * hxyz
    %
    %  hxyz and new_pts are both (3 by N).
    %
    %  Now, post-multiply both sides by the hxyz transposed.  
    %  On the left this becomes (3 by N ) * ( N by 3 ).
    %  The inside dimensions cancel, and the left side becomes
    %  (3 by 3 ):
    %
    %         (new_pts * hxyz.')  = MM * (hxyz * hxyz.') 
    %
    %  So, the left side is a (3 x 3 ) matrix.
    %  Let's hope that an inverse exists.  Then we can post-multiply both sides by inv( hxyz * hxyz.' ):
    %  
    %         (new_pts * hxyz.') * inv( hxyz * hxyz.' ) = MM * (hxyz * hxyz.') * inv( hxyz * hxyz.' )
    %
    %  Anything times it's own inverse is the identity matrix.  
    %  So, the right hand side becomes:
    %
    %         (new_pts * hxyz.') * inv( hxyz * hxyz.' ) = MM 
    %
    %  That's it.  That is what gives us the transformation matrix we would like.
    %  This should be ( 3 x 3 ).
    %  Let's check the dimensions:
    %
    %  ( 3 x N ) * ( N * 3 ) * inv( ( 3 x N ) * ( N x 3 ) )
    %  ( 3       x       3 ) * inv( ( 3       x       3 ) )
    %  ( 3                   x                        3   )
    %  
    %  So, it works, MM ends up being 3x3.
    %
    MM1 = (new_pts * hxyz.') * inv( hxyz * hxyz.' )
    
    %  In Matlab we can use the slash operator to say, "Figure it out:"
    %
    %  new_pts = MM * hxyz
    %  new_pts / hxyz = MM
    MM2 = new_pts / hxyz
    
    %  In some cases, especially when the data is stored in columns instead of
    %  rows, you use the backslash operator.
    %
    %  In any case, you can find the conversion matrix that goes from right to left,
    %  and from left to right.
    % 
    %  If   new_pts = MM2 * hxyz
    %
    %  Then   inv(MM2) * new_pts  = inv(MM2) * MM2 * hxyz
    %  or     inv(MM2) * new_pts  = hxyz
    
    
    
end



