function DEMO_17_blkproc()

        I = rgb2gray( imread('IMG_0842__WHITE_GOLFBALLS__smr.jpg') );
        dims = size( I );
        
        % SHRINK I for fitting on the screen:
        I = imresize( I, round( dims/2 ), 'nearest' );
        dims = size( I );
        
        fun = @dct2;
        J = blkproc(I,[8 8],fun);
        
        %
        %  EXTRACT THE FIRST EDGE DCT COEFFICIENTS, AND ADD THEM UP.
        %  Use the absolute values to be sure that they don't cancel each
        %  other out.  Negative amounts indicate coefs that are in the
        %  opposite direction.
        %
%         coef_12     = abs( J( 1:8:end, 2:8:end ) );
%         coef_22     = abs( J( 2:8:end, 2:8:end ) );
%         coef_21     = abs( J( 2:8:end, 1:8:end ) );
        coef_11     = abs( J( 1:8:end, 1:8:end ) );
        
        coefs_avg   = coef_11;
        

        
        figure;
        imagesc( I );
        colormap(gray);
        title('Image - Spacial ', 'FontSize', 22 );
        
        figure;
        imagesc( coefs_avg );
        colormap(gray);
        title('Image - DCT ', 'FontSize', 22 );
        
%         small_im    = J( 1:8:end, 1:8:end );
%         figure;
%         imagesc( small_im );
%         colormap(gray);
%         title('Image - FIRST DCT COEF ONLY ', 'FontSize', 22 );
  
end

