
function fig_id = zoom_figure( figure_size, b_center )
%fig_id = zoom_figure( [width, height], bool_center_in_monitor )
%
%  Create a figure when you have multiple monitors up.
%  Assumes that the right-most monitor is the one being shared, and 
%  the one on the far right hand side.  
%
%  *This assumption is easily wrong, depending on the user.*
%
%  bool_center_in_monitor == if true, try to center the position.
%
%
%  Written by Dr. Thomas B. Kinsman because it was necessary 
%  when lecturing over Zoom.
%
%  Date: '13-Mar-2020'
%

    % Create a random shift, so that subsequent figures do not always overlap.
    random_wd_margin = round( rand(1,1)*30 );
    random_ht_margin = round( rand(1,1)*40 );

    if ( nargin < 1 )
        desired_wd      = 1024;
        desired_ht      = 768;
        b_center        = false;
    else
        desired_wd = figure_size(1);
        desired_ht = figure_size(2);
        if ( nargin < 2 )
            b_center = false;
        end
    end

    MonitorPosit = get(0,'MonitorPositions');
    number_of_monitors = size(MonitorPosit,1);
    if ( number_of_monitors == 1 )
        % Only one screen:
        % Make position with respect to monitor 1 only:

        % Get screen Size:
        ss = get(0,'ScreenSize');
        if ( desired_ht > ss(4) )           desired_ht = ss(4);    random_ht_margin = 0;      end
        if ( desired_wd > ss(3) )           desired_wd = ss(3);    random_wd_margin = 0;      end

        
        scr_wd     = MonitorPosit(1,3);
        if ( b_center )
            left_shift = (scr_wd - desired_wd)/2 + random_wd_margin;
            bott_shift = (MonitorPosit(1,4)-desired_ht)/4+random_ht_margin;
        else
            left_shift = MonitorPosit(1,3)-desired_wd-random_wd_margin;
            bott_shift = MonitorPosit(1,2)+random_ht_margin;
        end

    else
        % Two or more screens:
        % Make position with respect to width of both monitors, assuming RHS monitor is biggest.

        % Sort monitors from left to right, use the right-most one:
        left__hand_edges = MonitorPosit(:,1);
        right_hand_edges = left__hand_edges + MonitorPosit(:,3);

        [~,sort_key]    = sort( right_hand_edges, 'ascend' );    % Find biggest ROW offset.
        MTU             = sort_key(end);      % Monitor_to_Use
        
        if ( b_center )
            % Center the figure in the RHS monitor:
            left_shift = MonitorPosit(MTU,3) + desired_wd/2 - random_wd_margin;

            % Make the bottom W.R.T. the bottom of the left monitor.
%           bot__shift = round( (MonitorPosit(2,4) - ht )/2 + random_ht_margin + MonitorPosit(2,2) );
            bott_shift = MonitorPosit(MTU,2)+random_ht_margin + (MonitorPosit(MTU,4) - desired_ht)/4;
        else
            % Put in the lower right hand corner.
            % Make position with respect to width of both monitors, assuming RHS monitor is biggest.
            % left_shift = ( left__hand_edges(1) + MonitorPosit(MTU,3) ) - ...
            %              (desired_wd-random_wd_margin);
            left_shift = ( left__hand_edges(MTU) ) + ...
                         ( random_wd_margin );
            bott_shift = MonitorPosit(MTU,2) + MonitorPosit(MTU,4)-random_ht_margin;
            
            % Clip to left side of monitor selected:
            if ( left_shift <= ( MonitorPosit(MTU,1)+MonitorPosit(MTU,3) ) )
                left_shift = ( MonitorPosit(MTU,1)+MonitorPosit(MTU,3) ) + 1;
            end
        end
    end
    
    fig_id = figure('Position', round([ left_shift, bott_shift, desired_wd, desired_ht ]), 'Color', 'w' );
    
end





