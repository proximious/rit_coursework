function xy_pts = house_pts( )
% Generate points on a house, for showing homogeneous coordinate transformations.
%
% Updated Oct-31-2018
%

xy_pts = [ ...
    0.00  0.00  1.50  2.50  2.50  2.75  2.75  3.00  3.00  1.75  0.00  1.75  1.75  2.25  2.25  3.00  3.00  1.00  1.00  0.50  0.50  0.50  1.00  1.00 -0.00 ;
    0.00  2.00  3.00  2.25  3.25  3.25  2.10  1.88  1.50  1.50  1.50  1.50  1.00  1.00  1.50  1.50  0.00 -0.00  1.50  1.50  0.00  0.25  0.25  0.00  0.00 ;
];

% Shift the house one half value up:
xy_pts(2,:) = xy_pts(2,:) + 1/2;

end

