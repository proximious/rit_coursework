function DEMO_04_Scaling_PTS()
%  Demonstrate scaling of points:
MS  =  8;                               % Marker Size.
FS  = 22;                               % Font size for labels and titles.

    xy_pts  = house_pts();              % Loaded from a pre-defined set of points.

    Scl     = eye(2) * 2.0;
    uv_pts  = Scl * xy_pts;
    
    % TBK routine:
    print_mat( Scl, 1, 'Scaling_Mat', 0 );

    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'ks-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [0 10 0 10]);
    xlabel( 'X Sample points ', 'FontSize', FS );
    ylabel( 'Y Value Computed ', 'FontSize', FS );
    title(  'Scaling by a constant factor.', 'FontSize', FS );
    
    hold on;

    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );
    legend( { 'Original Points ', 'Transformed Points ' }, ...
            'FontSize', FS, 'Location', 'NorthEast' );
end


