function DEMO_18_blkproc()

        I = rgb2gray( imread('IMG_0828__COLOR_GOLFBALLS__smr.jpg') );
        dims = size( I );
        
        % SHRINK I for fittin on the screen:
        I = imresize( I, round( dims/2 ), 'nearest' );
        dims = size( I );
        
        fun = @dct2;
        J = blkproc(I,[8 8],fun);
        
        figure;
        imagesc( I );
        colormap(gray);
        title('Image - Spacial ', 'FontSize', 22 );
        
        figure;
        imagesc(J);
        colormap(gray);
        title('Image - DCT ', 'FontSize', 22 );
        
        small_im    = J( 1:8:end, 1:8:end );
        figure;
        imagesc( small_im );
        colormap(gray);
        title('Image - FIRST DCT COEF ONLY ', 'FontSize', 22 );
  
end

