function DEMO_03_Rotating_PTS()
%  SOME POINTS:
MS  = 8;                                % Marker Size.
FS  = 22;                               % Font size for labels and titles.

    xy_pts = house_pts();               % Loaded from a pre-defined set of points.


    %
    %  This is a rotation matrix about the origin.
    %
    %  Pay attention to NU.  It is an angle, in radians.
    %  AND it is a POSITIVE value.  
    %  So, this rotates the POINTS (not the axis) clockwise.
    %
    nu                 =  + 30 * pi / 180;           % Thirty degrees in radians.
    RotationMatrix     =  [ cos(nu)   sin(nu) ; 
                           -sin(nu)   cos(nu) ];

    % Compute the rotated points:
    uv_pts  = RotationMatrix * xy_pts;


    % 
    zoom_figure( [1024 768] );
    plot( xy_pts(1,:), xy_pts(2,:), 'ks-', 'MarkerSize', MS, 'MarkerFaceColor', 'b' );
    grid on;
    axis equal;
    axis( [-2 5 -2 5 ]);
    xlabel( 'X ',  'FontSize', FS );
    ylabel( 'Y ',  'FontSize', FS );
    title(  'Rotation is in the POSITIVE direction. ', 'FontSize', FS );
    
    hold on;
    
    drawnow
    pause(2);
    
    plot( uv_pts(1,:), uv_pts(2,:), 'ro-', 'MarkerSize', MS, 'MarkerFaceColor', 'r' );
    

    legend( {'Original Points ', 'Rotated Points '}, ...
            'FontSize', 28, ...
            'Location', 'North' );
end


