# database-system-implementation
RIT CSCI 421 - Database System Implementation

Group 11

Iacob, Alex, ai9388

Maggiolo Cabrera, Carly, cm1748

Nguyen, Hai-Yen, hnn2306

Silva, Alexander-Joseph, aas3992


Availibility:

https://www.when2meet.com/?18439865-GmVBc

Documents:

Writeups found in writeups/


Project Requirements:

https://docs.google.com/document/d/11nryC8fkJ2tnQ10sDe3ddnFzvIVu_6O3c1RNKVE0YGk/edit?usp=share_link

How to run:

javac *.java
java Main <db loc> <page size> <buffer size>
